export class Pokemon {
  nombre: string;
  peso: string;
  tipo: string;

  constructor( ){

      this.nombre = '';
      this.peso = '';
      this.tipo = '';

  }
}
